# -*- coding: utf-8 -*-
"""
Created on Mon Jun  5 17:03:07 2017

@author: 248948
"""
from distutils.core import setup

setup(name='data_structure_algorithm',
      version='1.0',
      description='data structure common algorithm package',
      author='chen',
      author_email='15260817193@139.com',
      packages=['data_structure_algorithm'],
     )